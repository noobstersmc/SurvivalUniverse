import java.util.HashMap;
import java.util.Map;

import org.bukkit.Bukkit;

import xyz.derkades.SSX_Connector.AddonClass;

public class code extends AddonClass{
	public Map<String, String> getPlaceholders() {
		final Map<String, String> map = new HashMap<String, String>();

		//map.put("online", Bukkit.getOnlinePlayers().size() + "");
		map.put("alive", net.noobsters.www.gamemodes.Meetup.Listeners.players.size() + "") ;
		map.put("online", Bukkit.getOnlinePlayers().size() + "");
		map.put("state", net.noobsters.www.gamemodes.Meetup.UHCMeetup.Stage) ;

		return map;
	}
}
